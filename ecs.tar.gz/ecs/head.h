#include<vector>
#include<iostream>
#include<math.h>
#include<stdio.h>
#include<algorithm>

using namespace std;
typedef long double Double;

